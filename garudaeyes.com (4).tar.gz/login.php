<?php
session_start();

// Konfigurasi koneksi database
$host = "localhost";
$dbname = "sql_garudaeyes_c";
$dbuser = "sql_garudaeyes_c";
$dbpass = "5580a5bb27d438";

// Koneksi ke MySQL
$conn = new mysqli($host, $dbuser, $dbpass, $dbname);
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

$error_message = "";

// Jika form dikirim
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $username = $_POST['email']; // field 'email' di form kita pakai sebagai username
    $password = md5($_POST['password']); // cocok dengan MD5 di database

    $stmt = $conn->prepare("SELECT * FROM users WHERE username=? AND password=?");
    $stmt->bind_param("ss", $username, $password);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $_SESSION['username'] = $username;
        header("Location: dashboard.php");
        exit();
    } else {
        $error_message = "Username atau password salah.";
    }

    $stmt->close();
}
$conn->close();
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Login — GARUDA EYES</title>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700;800&display=swap" rel="stylesheet">
  <style>
    :root{
      --bg:#050507;
      --card:#0b0b0d;
      --muted:#9aa0a6;
      --accent:#7c3aed;
      --accent-2:#06b6d4;
      --glass: rgba(255,255,255,0.03);
    }
    *{box-sizing:border-box;margin:0;padding:0}
    html,body{height:100%}
    body{
      font-family:Inter, system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial;
      background: var(--bg);
      color:#e6edf3;
      display:flex;align-items:center;justify-content:center;padding:32px;overflow:hidden;
    }
    canvas#particles{
      position:fixed;top:0;left:0;width:100%;height:100%;z-index:0;
    }
    .bg-wave{
      position:absolute;bottom:-60px;left:0;width:200%;height:200px;
      background:linear-gradient(135deg,var(--accent),var(--accent-2));
      opacity:0.1;animation:waveMove 8s linear infinite;
      transform:skewY(-3deg);
    }
    @keyframes waveMove{
      0%{transform:translateX(0) skewY(-3deg)}
      100%{transform:translateX(-50%) skewY(-3deg)}
    }
    .card{
      position:relative;z-index:1;width:420px;max-width:94%;
      background:linear-gradient(180deg, rgba(255,255,255,0.02), rgba(255,255,255,0.01));
      border-radius:14px;padding:28px;box-shadow:0 10px 30px rgba(2,6,23,0.7);
      border:1px solid rgba(255,255,255,0.04);
    }
    .brand{display:flex;align-items:center;gap:14px;margin-bottom:18px}
    .logo{
      width:56px;height:56px;border-radius:12px;display:flex;align-items:center;justify-content:center;
      font-weight:800;background:linear-gradient(135deg,var(--accent),var(--accent-2));color:white;font-size:20px;
    }
    .brand h1{font-size:18px;letter-spacing:-0.2px}
    .brand p{color:var(--muted);font-size:13px}
    form{display:flex;flex-direction:column;gap:12px}
    label{font-size:13px;color:var(--muted)}
    .input{
      background:var(--glass);border-radius:10px;padding:12px 14px;border:1px solid rgba(255,255,255,0.03);
      color:inherit;font-size:15px;width:100%;
    }
    .btn{
      margin-top:8px;padding:12px 14px;border-radius:10px;border:0;cursor:pointer;font-weight:600;font-size:15px;
      background:linear-gradient(90deg,var(--accent),var(--accent-2));color:white;
    }
    .meta{display:flex;justify-content:space-between;margin-top:10px;color:var(--muted);font-size:13px}
    .divider{height:1px;background:linear-gradient(90deg,transparent,rgba(255,255,255,0.03),transparent);margin:14px 0}
    .socials{display:flex;gap:10px}
    .socials button{flex:1;padding:10px;border-radius:10px;border:1px solid rgba(255,255,255,0.03);background:transparent;color:var(--muted)}
    .error{background:rgba(255,40,72,0.08);color:#ff6b81;border:1px solid rgba(255,40,72,0.12);padding:10px;border-radius:8px;font-size:13px;margin-top:12px}
  </style>
</head>
<body>
  <canvas id="particles"></canvas>
  <div class="bg-wave"></div>
  <div class="card">
    <div class="brand">
      <div class="logo">GE</div>
      <div>
        <h1>GARUDA EYES</h1>
        <p>Masuk untuk melanjutkan ke dasbor</p>
      </div>
    </div>
    <?php if (!empty($error_message)): ?>
      <div class="error"><?php echo $error_message; ?></div>
    <?php endif; ?>
    <form action="login.php" method="POST">
      <div>
        <label>Username</label>
        <input class="input" name="email" type="text" placeholder="Masukkan username" required>
      </div>
      <div>
        <label>Kata Sandi</label>
        <input class="input" name="password" type="password" placeholder="Masukkan kata sandi" required>
      </div>
      <button class="btn" type="submit">Masuk</button>
      <div class="meta">
        <span>Belum punya akun?</span>
        <a href="#" style="color:white;text-decoration:none;">Daftar</a>
      </div>
      <div class="divider"></div>
      <div class="socials">
        <button type="button">Google</button>
        <button type="button">GitHub</button>
      </div>
    </form>
  </div>
  <script>
    const canvas=document.getElementById('particles');
    const ctx=canvas.getContext('2d');
    let particles=[];
    function resize(){canvas.width=window.innerWidth;canvas.height=window.innerHeight}
    window.addEventListener('resize',resize);resize();
    for(let i=0;i<80;i++){
      particles.push({x:Math.random()*canvas.width,y:Math.random()*canvas.height,vx:(Math.random()-0.5)*0.5,vy:(Math.random()-0.5)*0.5,r:Math.random()*2+1});
    }
    function draw(){
      ctx.clearRect(0,0,canvas.width,canvas.height);
      ctx.fillStyle='white';
      particles.forEach(p=>{
        p.x+=p.vx;p.y+=p.vy;
        if(p.x<0||p.x>canvas.width)p.vx*=-1;
        if(p.y<0||p.y>canvas.height)p.vy*=-1;
        ctx.beginPath();ctx.arc(p.x,p.y,p.r,0,Math.PI*2);ctx.fill();
      });
      requestAnimationFrame(draw);
    }
    draw();
  </script>
</body>
</html>
