<?php
// init.php — include this at the very top of every PHP page (before any HTML/output)

// konfigurasi domain dan secure
$site_domain = 'garudaeyes.com'; // GANTI jika berbeda
$use_https = true; // set true kalau situs pake HTTPS

// Set cookie params *SEBELUM* session_start()
$cookieParams = [
    'lifetime' => 0,
    'path'     => '/',
    'domain'   => $site_domain,      // pastikan domain sesuai (garudaeyes.com)
    'secure'   => $use_https,        // true jika pakai HTTPS
    'httponly' => true,
    'samesite' => 'Lax'              // Lax umumnya cocok; ganti 'None' kalau butuh cross-site (dengan secure=true)
];

// PHP 7.3+ style
session_set_cookie_params($cookieParams);

// prefer strict mode
ini_set('session.use_strict_mode', 1);

// Optional: jika butuh sesi lebih panjang, atur gc_maxlifetime
// ini_set('session.gc_maxlifetime', 86400); // 1 hari

// Mulai session
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// helper: force HTTPS (opsional)
if ($use_https && (!isset($_SERVER['HTTPS']) || $_SERVER['HTTPS'] === 'off')) {
    $redirect = 'https://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
    header('Location: ' . $redirect);
    exit();
}
