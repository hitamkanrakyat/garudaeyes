<?php
require_once __DIR__.'/init.php'; // jalankan before any output

if (!isset($_SESSION['username'])) {
    header('Location: /login.html'); // atau login.php
    exit();
}

?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>GARUDA EYES</title>
<style>
    body {
        background-color: #0f0f10;
        color: white;
        font-family: Arial, sans-serif;
        margin: 0;
        padding: 20px;
    }
    h1 {
        font-size: 28px;
        margin-bottom: 20px;
        text-align: center;
    }
    .container {
        max-width: 1000px;
        margin: auto;
        padding: 20px 0;
    }
    .grid-2 {
        display: grid;
        grid-template-columns: repeat(2, 1fr);
        gap: 20px;
        margin-bottom: 20px;
    }
    .grid-3 {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 20px;
    }
    .card {
        background-color: #151516;
        border-radius: 12px;
        padding: 20px;
        border: 1px solid rgba(255,255,255,0.05);
        box-shadow: 0 0 0 rgba(0,224,255,0);
        transition: all 0.3s ease-in-out;
        cursor: pointer;
    }
    .card:hover {
        box-shadow: 0 0 15px rgba(0,224,255,0.6);
        transform: translateY(-5px);
        border-color: rgba(0,224,255,0.5);
    }
    .card svg {
        width: 48px;
        height: 48px;
        fill: none;
        stroke: #00e0ff;
        stroke-width: 2;
        margin-bottom: 15px;
    }
    .card h3 {
        margin: 0;
        font-size: 18px;
    }
    .card p {
        color: #aaa;
        font-size: 14px;
        line-height: 1.4;
        margin-bottom: 15px;
    }
    .btn {
        display: inline-block;
        background-color: transparent;
        color: #00e0ff;
        padding: 8px 14px;
        border-radius: 6px;
        font-size: 14px;
        text-decoration: none;
        border: 1px solid #00e0ff;
        transition: 0.3s;
    }
    .btn:hover {
        background-color: #00e0ff;
        color: black;
    }
    .profile {
        display: flex;
        align-items: center;
        gap: 15px;
    }
    .avatar {
        width: 60px;
        height: 60px;
        background-color: #2a2a2a;
        border-radius: 50%;
        flex-shrink: 0;
    }
    @media (max-width: 800px) {
        .grid-2 {
            grid-template-columns: 1fr;
        }
        .grid-3 {
            grid-template-columns: 1fr;
        }
    }
</style>
</head>
<body>

<h1>GARUDA EYES</h1>

<div class="container">
    <!-- Baris Pertama -->
    <div class="grid-2">
        <!-- Profil User -->
        <div class="card">
            <div class="profile">
                <div class="avatar"></div>
                <div>
                    <h3>Lingga Lesmana</h3>
                    <p style="margin:0; font-size:13px; color:#ccc;">Teknisi</p>
                </div>
            </div>
            <p style="margin-top:15px; font-size:13px;">Email:<br>lingga.lesmana@example.com</p>
            <p style="font-size:13px;">Lokasi:<br>Makassar, Indonesia</p>
        </div>

        <!-- Cekpos -->
        <div class="card">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                <circle cx="12" cy="12" r="10"/>
                <circle cx="12" cy="12" r="4"/>
            </svg>
            <h3>fitur1</h3>
            <p>ini adalah fitur1</p>
            <a href="https://www.youtube.com/watch?v=EQklfRc1jpQ" target="_blank" class="btn">Lihat fitur1</a>
        </div>
    </div>

    <!-- Baris Kedua -->
    <div class="grid-3">
        <!-- Profiling 1 -->
        <div class="card">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                <circle cx="12" cy="8" r="4"/>
                <path d="M4 20c0-4 4-6 8-6s8 2 8 6"/>
            </svg>
            <h3>fitur2</h3>
            <p>ini adalah fitur</p>
            <a href="https://www.youtube.com/watch?v=EQklfRc1jpQ" target="_blank" class="btn">Lihat fitur2</a>
        </div>

        <!-- Profiling 2 -->
        <div class="card">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                <circle cx="12" cy="8" r="4"/>
                <path d="M4 20c0-4 4-6 8-6s8 2 8 6"/>
            </svg>
            <h3>fitur 3</h3>
            <p>lihat fitru3</p>
            <a href="https://www.youtube.com/watch?v=EQklfRc1jpQ" target="_blank" class="btn">Lihat fitur3</a>
        </div>

        <!-- Face Recognition -->
        <div class="card">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                <rect x="4" y="4" width="16" height="16" rx="2"/>
                <circle cx="12" cy="12" r="3"/>
            </svg>
            <h3>Fitur4</h3>
            <p>ini adalah fitur4</p>
            <a href="https://www.youtube.com/watch?v=EQklfRc1jpQ" target="_blank" class="btn">Lihat fitur4</a>
        </div>
    </div>
</div>
         <a href="logout.php" class="btn">Logout</a>
</body>
</html>
